create function get_izobrazba()
    returns TABLE(id integer, naziv text)
    language sql
as
$$
SELECT i.id, i.naziv::text AS naziv
FROM "Izobrazba" i
ORDER BY i.id;
$$;

alter function get_izobrazba() owner to postgres;

