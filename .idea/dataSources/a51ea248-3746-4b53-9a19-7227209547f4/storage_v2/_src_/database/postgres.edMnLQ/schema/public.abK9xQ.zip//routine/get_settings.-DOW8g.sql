create function get_settings(p_prefix text)
    returns TABLE(name text, value text)
    language sql
as
$$
    SELECT s.name, s.value
    FROM public.settings s
    WHERE s.name LIKE (p_prefix || '%')
    ORDER BY s.name;
$$;

alter function get_settings(text) owner to postgres;

