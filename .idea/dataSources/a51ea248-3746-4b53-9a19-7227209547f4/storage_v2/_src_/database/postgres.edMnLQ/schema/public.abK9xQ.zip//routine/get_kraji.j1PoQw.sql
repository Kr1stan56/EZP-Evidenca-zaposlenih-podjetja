create function get_kraji()
    returns TABLE(id integer, ime text)
    language sql
as
$$
SELECT k.id, k.ime::text AS ime
FROM kraji k
ORDER BY k.ime;
$$;

alter function get_kraji() owner to postgres;

