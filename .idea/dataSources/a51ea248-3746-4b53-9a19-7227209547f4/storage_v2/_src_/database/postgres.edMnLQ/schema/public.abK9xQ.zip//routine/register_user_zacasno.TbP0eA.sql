create function register_user_začasno(p_username text, p_password_hash text, p_email text) returns boolean
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT 1 FROM admin_users WHERE username = p_username) THEN
        RETURN FALSE;
    END IF;

    INSERT INTO admin_users(username, password, email)
    VALUES (p_username, p_password_hash, p_email);

    RETURN TRUE;
END;
$$;

alter function register_user_začasno(text, text, text) owner to postgres;

