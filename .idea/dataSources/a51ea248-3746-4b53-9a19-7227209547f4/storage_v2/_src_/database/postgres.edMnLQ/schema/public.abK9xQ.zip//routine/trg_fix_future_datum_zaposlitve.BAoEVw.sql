create function trg_fix_future_datum_zaposlitve() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.datum_zaposlitve > CURRENT_DATE THEN
  NEW.datum_zaposlitve := CURRENT_DATE;

  INSERT INTO log_akcij(akcija, uporabnik, "timestamp")
  VALUES ('POPRAAVLJEN DATUM ZAPOSLITVE (AUTO)', current_user, now());
END IF;


  RETURN NEW;
END;
$$;

alter function trg_fix_future_datum_zaposlitve() owner to postgres;

