create function get_oddelki(p_delovno_mesto_id integer)
    returns TABLE(id integer, naziv text)
    language sql
as
$$
SELECT o.id, o.ime::text AS naziv
FROM delovno_mesto_oddelek dmo
JOIN oddelki o ON o.id = dmo.oddelek_id
WHERE dmo.delovno_mesto_id = p_delovno_mesto_id
ORDER BY o.ime;
$$;

alter function get_oddelki(integer) owner to postgres;

