create function delete_employee(p_id integer) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM zaposleni WHERE id = p_id;
END;
$$;

alter function delete_employee(integer) owner to postgres;

