create function get_delovna_mesta()
    returns TABLE(id integer, naziv text)
    language sql
as
$$
    SELECT id, naziv FROM delovna_mesta ORDER BY naziv;
$$;

alter function get_delovna_mesta() owner to postgres;

