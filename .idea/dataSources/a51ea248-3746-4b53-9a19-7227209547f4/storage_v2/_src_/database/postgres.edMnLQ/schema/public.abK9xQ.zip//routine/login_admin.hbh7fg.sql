create function login_admin(p_username character varying)
    returns TABLE(password character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT u.password
    FROM admin_users u
    WHERE u.username = p_username;
END;
$$;

alter function login_admin(varchar) owner to postgres;

