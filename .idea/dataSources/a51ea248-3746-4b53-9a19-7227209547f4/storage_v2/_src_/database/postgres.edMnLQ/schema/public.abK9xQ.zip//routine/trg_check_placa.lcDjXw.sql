create function trg_check_placa() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.placa < 0 THEN
    RAISE EXCEPTION 'Plača ne sme biti negativna!';
  END IF;

  RETURN NEW;
END;
$$;

alter function trg_check_placa() owner to postgres;

