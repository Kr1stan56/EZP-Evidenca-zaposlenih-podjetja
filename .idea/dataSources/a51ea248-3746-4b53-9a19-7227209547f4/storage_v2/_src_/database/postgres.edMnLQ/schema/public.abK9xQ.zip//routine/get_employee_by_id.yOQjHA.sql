create function get_employee_by_id(p_id integer)
    returns TABLE(ime text, priimek text, email text, telefon text, placa numeric, datum_zaposlitve date, delovno_mesto_id integer, oddelek_id integer, kraj_id integer)
    language sql
as
$$
SELECT
  z.ime,
  z.priimek,
  z.email,
  z.telefon,
  z.placa,
  z.datum_zaposlitve,
  z.delovno_mesto_id,
  z.oddelek_id,
  z.kraj_id
FROM zaposleni z
WHERE z.id = p_id;
$$;

alter function get_employee_by_id(integer) owner to postgres;

