create function add_employee(p_ime text, p_priimek text, p_email text, p_telefon text, p_placa numeric, p_datum date, p_delovno_mesto_id integer, p_kraj_id integer, p_izobrazba_id integer) returns integer
    language sql
as
$$
INSERT INTO zaposleni(ime, priimek, email, telefon, placa, datum_zaposlitve, delovno_mesto_id, kraj_id, izobrazba_id)
VALUES (p_ime, p_priimek, p_email, p_telefon, p_placa, p_datum, p_delovno_mesto_id, p_kraj_id, p_izobrazba_id)
RETURNING id;
$$;

alter function add_employee(text, text, text, text, numeric, date, integer, integer, integer) owner to postgres;

