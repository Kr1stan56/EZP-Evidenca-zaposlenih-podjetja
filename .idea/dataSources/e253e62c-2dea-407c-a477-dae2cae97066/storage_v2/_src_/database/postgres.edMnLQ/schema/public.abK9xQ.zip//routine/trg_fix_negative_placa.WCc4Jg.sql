create function trg_fix_negative_placa() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.placa < 0 THEN
    -- nastavi na 1000
    NEW.placa := 1000;

    -- zapiši v log
    INSERT INTO log_akcij(akcija, uporabnik, "timestamp")
    VALUES (
      'NEGATIVNA PLAČA – nastavljena na 1000 (zaposleni id=' || COALESCE(NEW.id, OLD.id) || ')',
      current_user,
      now()
    );
  END IF;

  RETURN NEW;
END;
$$;

alter function trg_fix_negative_placa() owner to postgres;

grant execute on function trg_fix_negative_placa() to anon;

grant execute on function trg_fix_negative_placa() to authenticated;

grant execute on function trg_fix_negative_placa() to service_role;

