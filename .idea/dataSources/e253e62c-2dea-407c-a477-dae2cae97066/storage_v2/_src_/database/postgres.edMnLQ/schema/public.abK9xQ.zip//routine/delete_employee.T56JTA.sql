create function delete_employee(p_id integer) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM zaposleni WHERE id = p_id;
END;
$$;

alter function delete_employee(integer) owner to postgres;

grant execute on function delete_employee(integer) to anon;

grant execute on function delete_employee(integer) to authenticated;

grant execute on function delete_employee(integer) to service_role;

