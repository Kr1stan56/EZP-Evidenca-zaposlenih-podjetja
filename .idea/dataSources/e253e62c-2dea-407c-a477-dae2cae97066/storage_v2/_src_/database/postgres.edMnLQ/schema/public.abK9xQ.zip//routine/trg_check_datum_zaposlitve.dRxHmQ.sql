create function trg_check_datum_zaposlitve() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.datum_zaposlitve > CURRENT_DATE THEN
    RAISE EXCEPTION USING
      ERRCODE = 'P0001',
      MESSAGE = 'Datum zaposlitve ne sme biti v prihodnosti 6.';
  END IF;
  RETURN NEW;
END;
$$;

alter function trg_check_datum_zaposlitve() owner to postgres;

grant execute on function trg_check_datum_zaposlitve() to anon;

grant execute on function trg_check_datum_zaposlitve() to authenticated;

grant execute on function trg_check_datum_zaposlitve() to service_role;

