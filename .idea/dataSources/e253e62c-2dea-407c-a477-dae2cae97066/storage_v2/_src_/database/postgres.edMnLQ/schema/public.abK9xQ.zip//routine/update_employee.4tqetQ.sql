create function update_employee(p_id integer, p_ime character varying, p_priimek character varying, p_email character varying, p_telefon character varying, p_placa numeric, p_datum date, p_delovno_mesto_id integer, p_oddelek_id integer, p_kraj_id integer, p_izobrazba_id integer) returns void
    language sql
as
$$
UPDATE zaposleni
SET ime = p_ime,
    priimek = p_priimek,
    email = p_email,
    telefon = p_telefon,
    placa = p_placa,
    datum_zaposlitve = p_datum,
    delovno_mesto_id = p_delovno_mesto_id,
    oddelek_id = p_oddelek_id,
    kraj_id = p_kraj_id,
    izobrazba_id = p_izobrazba_id
WHERE id = p_id;
$$;

alter function update_employee(integer, varchar, varchar, varchar, varchar, numeric, date, integer, integer, integer, integer) owner to postgres;

grant execute on function update_employee(integer, varchar, varchar, varchar, varchar, numeric, date, integer, integer, integer, integer) to anon;

grant execute on function update_employee(integer, varchar, varchar, varchar, varchar, numeric, date, integer, integer, integer, integer) to authenticated;

grant execute on function update_employee(integer, varchar, varchar, varchar, varchar, numeric, date, integer, integer, integer, integer) to service_role;

