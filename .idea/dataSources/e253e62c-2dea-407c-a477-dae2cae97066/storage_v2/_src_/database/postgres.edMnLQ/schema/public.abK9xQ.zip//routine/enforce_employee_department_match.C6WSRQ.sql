create function enforce_employee_department_match() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.oddelek_id IS NULL THEN
    RETURN NEW;
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM delovno_mesto_oddelek dmo
    WHERE dmo.delovno_mesto_id = NEW.delovno_mesto_id
      AND dmo.oddelek_id = NEW.oddelek_id
  ) THEN
    RAISE EXCEPTION 'Oddelek % ni dovoljen za delovno mesto %', NEW.oddelek_id, NEW.delovno_mesto_id;
  END IF;

  RETURN NEW;
END;
$$;

alter function enforce_employee_department_match() owner to postgres;

grant execute on function enforce_employee_department_match() to anon;

grant execute on function enforce_employee_department_match() to authenticated;

grant execute on function enforce_employee_department_match() to service_role;

