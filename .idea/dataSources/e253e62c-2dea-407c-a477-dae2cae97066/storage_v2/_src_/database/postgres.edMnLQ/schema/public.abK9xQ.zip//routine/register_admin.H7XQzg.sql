create function register_admin(p_username text, p_password text, p_email text) returns boolean
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT 1 FROM admin_users WHERE username = p_username) THEN
        RETURN FALSE;
    END IF;

    INSERT INTO admin_users(username, password, email)
    VALUES (p_username, p_password, p_email);

    RETURN TRUE;
END;
$$;

alter function register_admin(text, text, text) owner to postgres;

grant execute on function register_admin(text, text, text) to anon;

grant execute on function register_admin(text, text, text) to authenticated;

grant execute on function register_admin(text, text, text) to service_role;

