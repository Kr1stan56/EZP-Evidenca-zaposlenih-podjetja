create function login_admin(p_username character varying)
    returns TABLE(password character varying, email character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT au.password, au.email 
    FROM admin_users au 
    WHERE au.username = p_username;
END;
$$;

alter function login_admin(varchar) owner to postgres;

grant execute on function login_admin(varchar) to anon;

grant execute on function login_admin(varchar) to authenticated;

grant execute on function login_admin(varchar) to service_role;

