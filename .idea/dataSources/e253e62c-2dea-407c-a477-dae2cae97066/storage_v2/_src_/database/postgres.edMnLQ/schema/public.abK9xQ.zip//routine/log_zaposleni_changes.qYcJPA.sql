create function log_zaposleni_changes() returns trigger
    language plpgsql
as
$$
BEGIN
  INSERT INTO log_akcij(akcija, uporabnik, "timestamp")
  VALUES (
    TG_OP || ' zaposleni id=' || COALESCE(NEW.id, OLD.id),
    current_user,
    now()
  );

  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;

  RETURN NEW;
END;
$$;

alter function log_zaposleni_changes() owner to postgres;

grant execute on function log_zaposleni_changes() to anon;

grant execute on function log_zaposleni_changes() to authenticated;

grant execute on function log_zaposleni_changes() to service_role;

