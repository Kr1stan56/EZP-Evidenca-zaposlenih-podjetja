create function get_izobrazba()
    returns TABLE(id integer, naziv text)
    language sql
as
$$
SELECT i.id, i.naziv::text AS naziv
FROM "Izobrazba" i
ORDER BY i.id;
$$;

alter function get_izobrazba() owner to postgres;

grant execute on function get_izobrazba() to anon;

grant execute on function get_izobrazba() to authenticated;

grant execute on function get_izobrazba() to service_role;

