create function get_delovna_mesta()
    returns TABLE(id integer, naziv text)
    language sql
as
$$
    SELECT id, naziv FROM delovna_mesta ORDER BY naziv;
$$;

alter function get_delovna_mesta() owner to postgres;

grant execute on function get_delovna_mesta() to anon;

grant execute on function get_delovna_mesta() to authenticated;

grant execute on function get_delovna_mesta() to service_role;

