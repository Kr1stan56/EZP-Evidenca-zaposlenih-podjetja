create function create_admin_with_email(p_username text, p_hash text, p_email text) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO admin_users(username, password, email)
    VALUES (p_username, p_hash, p_email);
END;
$$;

alter function create_admin_with_email(text, text, text) owner to postgres;

