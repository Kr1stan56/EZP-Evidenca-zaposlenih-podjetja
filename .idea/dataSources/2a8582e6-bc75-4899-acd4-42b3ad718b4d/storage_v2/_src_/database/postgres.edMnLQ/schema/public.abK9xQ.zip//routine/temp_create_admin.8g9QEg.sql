create function temp_create_admin(p_user text, p_hash text) returns void
    language sql
as
$$
    INSERT INTO admin_users(username, password)
    VALUES (p_user, p_hash);
$$;

alter function temp_create_admin(text, text) owner to postgres;

