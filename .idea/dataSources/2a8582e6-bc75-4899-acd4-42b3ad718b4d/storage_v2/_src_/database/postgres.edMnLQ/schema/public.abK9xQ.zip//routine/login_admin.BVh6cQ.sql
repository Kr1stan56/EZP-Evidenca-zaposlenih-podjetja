create function login_admin(p_username text)
    returns TABLE(password text)
    language sql
as
$$
    SELECT password
    FROM admin_users
    WHERE username = p_username;
$$;

alter function login_admin(text) owner to postgres;

