create function get_setting(p_name character varying) returns character varying
    language sql
as
$$
    SELECT s.value
    FROM settings s
    WHERE s.name = p_name
    LIMIT 1;
$$;

alter function get_setting(varchar) owner to postgres;

