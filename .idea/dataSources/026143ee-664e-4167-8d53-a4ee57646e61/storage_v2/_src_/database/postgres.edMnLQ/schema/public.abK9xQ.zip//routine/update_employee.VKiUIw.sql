create function update_employee(p_id integer, p_ime text, p_priimek text, p_email text, p_telefon text, p_placa numeric, p_datum_zaposlitve date, p_delovno_mesto_id integer, p_oddelek_id integer, p_kraj_id integer) returns void
    language plpgsql
as
$$
BEGIN
    UPDATE zaposleni
    SET ime = p_ime,
        priimek = p_priimek,
        email = p_email,
        telefon = p_telefon,
        placa = p_placa,
        datum_zaposlitve = p_datum_zaposlitve,
        delovno_mesto_id = p_delovno_mesto_id,
        oddelek_id = p_oddelek_id,
        kraj_id = p_kraj_id
    WHERE id = p_id;
END;
$$;

alter function update_employee(integer, text, text, text, text, numeric, date, integer, integer, integer) owner to postgres;

