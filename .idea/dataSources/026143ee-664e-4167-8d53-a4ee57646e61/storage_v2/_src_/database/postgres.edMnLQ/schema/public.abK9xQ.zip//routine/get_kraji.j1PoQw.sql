create function get_kraji()
    returns TABLE(id integer, naziv text)
    language sql
as
$$
    SELECT id, ime FROM kraji ORDER BY ime;
$$;

alter function get_kraji() owner to postgres;

