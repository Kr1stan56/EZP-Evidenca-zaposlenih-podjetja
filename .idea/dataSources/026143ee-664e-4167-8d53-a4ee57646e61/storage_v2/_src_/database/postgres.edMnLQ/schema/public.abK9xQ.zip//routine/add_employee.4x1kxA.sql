create function add_employee(p_ime character varying, p_priimek character varying, p_email character varying, p_telefon character varying, p_placa real, p_datum_zaposlitve date, p_delovno_mesto_id integer, p_oddelek_id integer, p_kraj_id integer, p_izobrazba_id integer) returns integer
    language plpgsql
as
$$
DECLARE
    new_id int;
BEGIN
    INSERT INTO zaposleni
        (ime, priimek, email, telefon, placa, datum_zaposlitve,
         delovno_mesto_id, oddelek_id, kraj_id, izobrazba_id)
    VALUES
        (p_ime, p_priimek, p_email, p_telefon, p_placa, p_datum_zaposlitve,
         p_delovno_mesto_id, p_oddelek_id, p_kraj_id, p_izobrazba_id)
    RETURNING id INTO new_id;

    RETURN new_id;
END;
$$;

alter function add_employee(varchar, varchar, varchar, varchar, real, date, integer, integer, integer, integer) owner to postgres;

