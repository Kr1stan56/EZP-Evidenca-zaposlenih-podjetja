create function get_all_employees()
    returns TABLE(id integer, ime character varying, priimek character varying, email character varying, telefon character varying, placa real, datum_zasposlitve date, delovno_mesto character varying, oddelek character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        z.id,
        z.ime,
        z.priimek,
        z.email,
        z.telefon,
        z.placa,
        z.datum_zasposlitve,
        dm.naziv as delovno_mesto,
        o.ime as oddelek
    FROM zaposleni z
    JOIN delovna_mesta dm ON z.delovno_mesto_id = dm.id
    JOIN oddelki o ON z.oddelek_id = o.id
    ORDER BY z.priimek, z.ime;
END;
$$;

alter function get_all_employees() owner to postgres;

