create function get_all_employees()
    returns TABLE(id integer, ime character varying, priimek character varying, email character varying, telefon character varying, placa real, datum_zaposlitve date, delovno_mesto character varying, oddelek character varying, kraj character varying, izobrazba character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        z.id,
        z.ime,
        z.priimek,
        z.email,
        z.telefon,
        z.placa,
        z.datum_zaposlitve,
        dm.naziv AS delovno_mesto,
        o.ime    AS oddelek,
        k.ime    AS kraj,
        i.naziv  AS izobrazba
    FROM zaposleni z
    JOIN delovna_mesta dm ON z.delovno_mesto_id = dm.id
    JOIN oddelki o        ON z.oddelek_id = o.id
    LEFT JOIN kraji k     ON z.kraj_id = k.id
    LEFT JOIN "Izobrazba" i ON z.izobrazba_id = i.id
    ORDER BY z.priimek, z.ime;
END;
$$;

alter function get_all_employees() owner to postgres;

