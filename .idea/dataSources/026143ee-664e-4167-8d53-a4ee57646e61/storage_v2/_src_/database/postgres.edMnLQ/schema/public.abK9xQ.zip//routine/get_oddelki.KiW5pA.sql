create function get_oddelki()
    returns TABLE(id integer, naziv text)
    language sql
as
$$
    SELECT id, ime FROM oddelki ORDER BY ime;
$$;

alter function get_oddelki() owner to postgres;

