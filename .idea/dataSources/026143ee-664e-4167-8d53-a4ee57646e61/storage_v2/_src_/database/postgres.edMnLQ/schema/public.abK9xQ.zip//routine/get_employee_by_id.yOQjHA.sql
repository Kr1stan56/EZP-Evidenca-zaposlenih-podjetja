create function get_employee_by_id(p_id integer)
    returns TABLE(ime text, priimek text, email text, telefon text, placa numeric, datum_zaposlitve date, delovno_mesto_id integer, oddelek_id integer, kraj_id integer)
    language sql
as
$$
    SELECT ime, priimek, email, telefon, placa, datum_zaposlitve,
           delovno_mesto_id, oddelek_id, kraj_id
    FROM zaposleni
    WHERE id = p_id;
$$;

alter function get_employee_by_id(integer) owner to postgres;

